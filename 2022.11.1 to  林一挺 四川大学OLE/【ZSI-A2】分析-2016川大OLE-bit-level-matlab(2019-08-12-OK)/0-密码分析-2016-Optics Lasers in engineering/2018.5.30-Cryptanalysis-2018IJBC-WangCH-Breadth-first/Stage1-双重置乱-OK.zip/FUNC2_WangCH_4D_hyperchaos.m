% �������ƣ�y_WangCH_4D_hyperchaos.m -OK
% 2018-International Journal of Bifurcation & Chaos-Wang CH-
% A New Chaotic Image Encryption Scheme Using Breadth-First Search and Dynamic Diffusion
% 2018.5.14 by whp 
% clc;clear;close all;

function Out=FUNC2_WangCH_4D_hyperchaos(N0,L)
options = odeset('RelTol',1e-6,'AbsTol',[1e-6 1e-6 1e-6 1e-6]);
t0=[0 105];
x0=[101,0.95,1.01,1.01];
[t,x]=ode45('WangCH_4D_hyperchaos',t0,x0,options);
n=length(t)
Out(1,:)=x(N0+1:N0+L,1);
Out(2,:)=x(N0+1:N0+L,2);
Out(3,:)=x(N0+1:N0+L,3);
Out(4,:)=x(N0+1:N0+L,4);
end

